// Re-export the toast functionality from the hook
export { useToast, toast } from "@/hooks/use-toast"
